#!/bin/sh 
# xrandr --newmode "2016x1343"  228.25  2016 2160 2376 2736  1343 1346 1356 1392 -hsync +vsync
# xrandr --addmode eDP-1 2016x1343
# xrandr -s 2016x1343

xrandr --newmode "1880x1253"  197.50  1880 2008 2208 2536  1253 1256 1266 1299 -hsync +vsync
xrandr --addmode eDP-1 1880x1253
xrandr -s 1880x1253
