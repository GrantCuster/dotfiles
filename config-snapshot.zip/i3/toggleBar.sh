#!/bin/bash

echo 'test'

# Check to see if our state log exists
if [ ! -f /tmp/monitor ]; then
  touch /tmp/monitor
  STATE=0
else
  STATE=$(</tmp/monitor)
fi

echo $STATE

if [ $STATE == 0 ]; then
  xdotool search --class Polybar windowmap %@ windowraise %@
  STATE=1
else
  xdotool search --class Polybar windowunmap %@
  STATE=0
fi

echo $STATE > /tmp/monitor
